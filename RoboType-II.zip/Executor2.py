### Class to simulate execution coordination 
import json
import numpy as np
import math
import random
from metrics import *
import re
import time as t

class Executor2:

    def __init__(self, finger, eye, keyboard, expert_factor=0.1):
        self.finger=finger
        self.eye=eye
        self.keyboard=keyboard
        self.eye.position = [keyboard.xdim/2, keyboard.ydim/2]
        self.plan=[]
        self.clock=0
        self.expert_factor = expert_factor
        self.eye_positions = []


    ## type a sentence and attempt to correct errors, if they occur
    # general strategy
    # 1. split sentence into words
    # 2. for each word, type every letter
    # 2.1 search for key in keyboard
    # 2.2 when found, press it
    # 2.3 with increasing probability, check the suggestions to see if the desired word is there
    # 2.4 type a word separator and move to next word

    def tote_attempt(self, target, speed, slides): #, stime=0):
        #TEST OPERATE TEST EXIT

        if self.keyboard.keylist[target]['type']=='suggestion':
            sugintention = self.keyboard.keylist[target]['label']
        else:
            sugintention=None
        
        #execute attempt
        outcome=self.search_and_tap(target,speed,slides) #, stime)

        #evaluate outcome
        #if outcome!=None:
        #    print('tried for',target, 'hit', outcome['label'], self.clock)
        #else:
        #    print('tried for',target,'hit None', self.clock)

        #good outcomes
        if outcome!=None:
            if outcome['type']!='suggestion' and outcome['label']==target:
        #        print('success')
                return 1
            if outcome['type']=='suggestion' and outcome['label']==sugintention:
        #        print('success')
                return 100
                
        #if outcome is wrong, we must fix it and try again
        #possible bad outcomes
        #intent key outcome NONE
        #intent key outcome wrong key
        #intent key outcome suggestion
        #intent key outcome delete
        #intent suggestion outcome none
        #intent suggestion outcome key
        #intent suggestion outcome wrong suggestion
        #intent delete outcome NONE
        #intent delete outcome key
        
        #print("shite")
        
        #t.sleep(0.5)

        #fix then try again
        
        if self.keyboard.keylist[target]['type']=='char' or self.keyboard.keylist[target]['type']=='suggestion':
            if outcome==None:
        #        print("hit nothing, trying again")
                #just try again
                return 0
            if outcome['type'] == 'char':
                #try to delete 1 char
        #        print("must attempt 1 delete")
                return -1
            if outcome['type']=='suggestion':
                #delete all suggestion letters
        #        print("must attempt",len(outcome['label']),"deletes")
                return -len(outcome['label'])
            if outcome['type']=='delete':
        #        print("accidental delete") #wanted a key, instead hit delete
                return -100
                
        #intended delete, hit something else            
        if self.keyboard.keylist[target]['type']=='delete':
            if outcome==None:
        #        print("hit nothing, trying again")
                return 0
                
            if outcome['type'] == 'char':
                #try to delete 1 char
        #        print("must attempt 1 delete")
                return  -1

    def search_and_tap(self,target,speed,slides): #, stime=0):
        
        #is the target where we're looking?
    #    print ("searching for ", target, end="\r")
        found = False
        searchcount=1
        total_time=0
        rng = np.random.default_rng()

        self.eye_positions.append({"pos":self.eye.position,"time":self.clock})

        #coming to a suggestion means we already found it previously
        if self.keyboard.keylist[target]['type']!='suggestion':
            while not found:
    #            print ("\r searching for "+ target+ "  "+str(searchcount), end="\r")
                
                #scan time to find key at current position
                found, time = self.eye.find_target_at_current_position(target, self.keyboard, factor=1)
                
                self.clock+=time
                
                if not found:
                    searchcount+=1
                    #move the eye at some random point within x SDs from target's coordinate
                    #when the user is more expert, sd of eye from target coords should be smaller
                    
                    newpos=[0,0]
                    newpos[0] = rng.normal(self.keyboard.keylist[target]['center'][0], 
                                              self.keyboard.keylist[target]['xlen']*self.expert_factor, 1)[0]
                    newpos[1] = rng.normal(self.keyboard.keylist[target]['center'][1], 
                                              self.keyboard.keylist[target]['ylen']*self.expert_factor, 1)[0]
                    
                    if newpos[0]<0:
                        newpos[0] = 0
                    else:
                        if newpos[0]>self.keyboard.xdim:
                            newpos[0]=self.keyboard.xdim

                    if newpos[1]<0:
                        newpos[1] = 0
                    else:
                        if newpos[1]>self.keyboard.ydim:
                            newpos[1]=self.keyboard.ydim
                    
                    #newpos = [random.randint(0,self.keyboard.xdim), random.randint(0,self.keyboard.ydim)]
                    movetime = self.eye.move_eye(self.eye.position, newpos)
                    time+=movetime
                    self.clock+=movetime
                    self.eye_positions.append({"pos":self.eye.position,"time":self.clock})
                    
                total_time+=time
        else:
            found=True
        
    #    print('\n found in '+str(total_time)+"ms")

        #OPERATE
        #move the finger to the key
        #eye will be near there too
        pos = self.finger.moveFingerKinematic(target, self.keyboard, speed, slides, self.clock) #total_time+stime)
        self.clock+=pos['finger_time']

        #TEST
        #see the outcome of the tap
        outcome=self.keyboard.outputLetter(pos)

        return outcome

    def typeSentenceWithCorrection2(self, sentence, speed, noticeprob, slides='on', completions=False):

        self.clock=0
        self.finger.position=[0,0]
        self.eye.position=[0,0]
        self.pos_list = []
        stime=0
        
        # 1. split sentence into words
        sentence_words = re.split("[^\w]", sentence)
        sentence_separators = re.findall("[^\w]", sentence)
        
    #    print(sentence_words)
    #    print(sentence_separators)
        
        for w in range(len(sentence_words)):
    #        print ('processing word '+sentence_words[w])
            
            self.plan=list(sentence_words[w])
            if w<len(sentence_words)-1:
                self.plan.append(sentence_separators[w])
            
            wordpos = 0
            
            while wordpos < len(self.plan):
    #            print('----------------')
    #            print ('plan', self.plan, 'wordpos',wordpos)
                #first type the letter
                
                #typeresult = self.tote_attempt(self.plan[wordpos], speed, slides, stime)
                typeresult = self.tote_attempt(self.plan[wordpos], speed, slides)
                #came from a suggestion, reset it
                if stime!=0:
                    stime=0
                    
                #nothing hit, try again
                if typeresult == 0:
                    continue

                #good hit, move to next plan step
                if typeresult>0:
                    if typeresult== 1:
                        wordpos+=1
                    if typeresult==100: #bingo we hit the suggestion
                        if w<len(sentence_words)-1:
                            wordpos=len(self.plan)-1
                            continue #so you  can  try the separator
                        else:
                            break
                        #print('moving to',sentence_words[w][wordpos])
                else:
                    #bad hits, typeresult is negative (number of needed deletes)
                    if typeresult == -100: #accidental deletes, go back a step in the plan
                        if wordpos>0: #check we have not accidentally pressed del on the 1st letter
                            wordpos-=1
                    else:
                        for i in range(-1*typeresult):
                            self.plan.insert(wordpos,'delete')
                            
                
                        
                #then check the suggestions
                if completions and wordpos>=2 and wordpos<len(self.plan)-1:             
                    #before moving to the next letter, chance to observe if a suggestion is available
                    #chance depends on letters typed already in composing word - for each letter add a 20% chance
                    
                    #chance = random.randint(0,100)
                    chance=-1
                    threshold = len(self.keyboard.current_word)*25
                    if chance<threshold:
       #                 print("checking suggestions for '"+sentence_words[w]+"'")
                        #sug_position,stime = self.eye.scan_suggestions(sentence_words[w], self.keyboard)
                        sug_position, eye_positions = self.eye.scan_suggestions(sentence_words[w], self.keyboard)
                        for pos in eye_positions:
                            self.clock+=pos['time']
                            self.eye_positions.append({"pos":pos['pos'], "time":self.clock})
                        if sug_position>=0:
       #                     print("word in suggestions"+str(sug_position))
                            self.plan.insert(wordpos, 'suggestion'+str(sug_position))
                                        
       #         print('----------------')   
        
       # print("--- Done typing ---")
        self.keyboard.outputbuffer+=self.keyboard.current_word
       # print("".join(self.keyboard.outputbuffer))
        return {"sentence": sentence,
                "output": "".join(self.keyboard.outputbuffer), 
                "wpm": wpm(self.keyboard.taps, "".join(self.keyboard.outputbuffer)),
                "kspc": kspc(self.keyboard.taps, "".join(self.keyboard.outputbuffer)),
                "taps": self.keyboard.taps}

    
