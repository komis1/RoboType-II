### Class to simulate execution coordination 
import json
import numpy as np
import math
import random
from metrics import *
import re
import time as t

class Executor:

    def __init__(self, finger, eye, keyboard):
        self.finger=finger
        self.eye=eye
        self.keyboard=keyboard
        self.eye.position = [keyboard.xdim/2, keyboard.ydim/2]


    ## type a sentence and attempt to correct errors, if they occur
    # general strategy
    # 1. split sentence into words
    # 2. for each word, type every letter
    # 2.1 search for key in keyboard
    # 2.2 when found, press it
    # 2.3 with increasing probability, check the suggestions to see if the desired word is there
    # 2.4 type a word separator and move to next word

    def tote_attempt(self, target, speed, slides):
        #TEST OPERATE TEST EXIT
        
        #is the target where we're looking?
        print ("searching for ", target, end="\r")
        found = False
        total_time=0
        searchcount=1
        while not found:
            print ("\r searching for "+ target+ "  "+str(searchcount), end="\r")
            found, time = self.eye.find_target(target, self.keyboard, factor=1)
            if not found:
                searchcount+=1
                self.eye.position[0]=random.randint(0,self.keyboard.xdim)
                self.eye.position[1]=random.randint(0,self.keyboard.ydim)
            total_time += time
        print('\n')

        #OPERATE
        #move the finger to the key
        #eye will be near there too
        pos = self.finger.moveFingerKinematic(target, self.keyboard, speed, slides)

        #TEST
        #see the outcome of the tap
        outcome=self.keyboard.outputLetter(pos)

        if outcome!=None:
            print('tried for',target, 'hit', outcome['label'])
        else:
            print('tried for',target,'hit None')

        #good outcomes
        if outcome!=None:
            if outcome['type']=='char' and outcome['label']==target:
                print('success')
                return 0
            if outcome['type']=='suggestion' and outcome['label']==self.keyboard.keylist[target]['label']:
                print('success')
                return 0
        

        
        #if outcome is wrong, we must fix it and try again
        #possible bad outcomes
        #intent key outcome NONE
        #intent key outcome wrong key
        #intent key outcome suggestion
        #intent key outcome delete
        #intent suggestion outcome none
        #intent suggestion outcome key
        #intent suggestion outcome wrong suggestion
        #intent delete outcome NONE
        #intent delete outcome key
        
        print("shite")
        
        t.sleep(0.5)

        #fix then try again
        
        if self.keyboard.keylist[target]['type']=='char' or self.keyboard.keylist[target]['type']=='suggestion':
            if outcome==None:
                print("hit nothing, trying again")
                #just try again
                self.tote_attempt(target, speed, slides)
                return 0
            if outcome['type'] == 'char':
                #try to delete 1 char
                print("attempting 1 delete")
                self.tote_attempt('delete', speed, slides)
                #just try again
                self.tote_attempt(target, speed, slides)
                return  0
            if outcome['type']=='suggestion':
                #delete all suggestion letters
                print("attempting",len(outcome['label']),"deletes")
                for i in range(len(outcome['label'])):
                    self.tote_attempt('delete', speed, slides)
                #just try again
                self.tote_attempt(target, speed, slides)
                return 0
            if outcome['type']=='delete':
                print("accidental delete") #wanted a key, instead hit delete
                return -1
                
        #intended delete, hit something else            
        if self.keyboard.keylist[target]['type']=='delete':
            if outcome==None:
                print("hit nothing, trying again")
                #just try again
                self.tote_attempt(target, speed, slides)
                return 0
                
            if outcome['type'] == 'char':
                #try to delete 1 char
                print("attempting 1 delete")
                self.tote_attempt('delete', speed, slides)
                #just try again
                self.tote_attempt(target, speed, slides)
                return  0
                
    def typeSentenceWithCorrection2(self, sentence, speed, noticeprob, slides='on', completions=False):   
        # 1. split sentence into words
        sentence_words = re.split("[^\w]", sentence)
        sentence_separators = re.findall("[^\w]", sentence)
        
        print(sentence_words)
        print(sentence_separators)
        
        for w in range(len(sentence_words)):
            print ('processing word '+sentence_words[w])
            wordpos = 0
            
            while wordpos < len(sentence_words[w]):
                
                #first type the letter
                typeresult = self.tote_attempt(sentence_words[w][wordpos], speed, slides)
                if typeresult == 0:
                    wordpos+=1
                    #print('moving to',sentence_words[w][wordpos])
                else:
                    #check we have not accidentally pressed del on the 1st letter
                    if wordpos>0: 
                        wordpos-=1
                        #print('backtracking to',sentence_words[w][wordpos])
                        
                #then check the suggestions
                if completions and wordpos>=2 and wordpos<len(sentence_words[w])-2:             
                    #before moving to the next letter, chance to observe if a suggestion is available
                    #chance depends on letters typed already in composing word - for each letter add a 20% chance
                    chance = random.randint(0,100)
                    threshold = len(self.keyboard.current_word)*20
                    if chance<threshold:
                        print("checking suggestions for '"+sentence_words[w]+"'")
                        sug_position = self.eye.scan_suggestions(sentence_words[w], self.keyboard)
                        if sug_position>=0:
                            print("word in suggestions"+str(sug_position))
                            if self.tote_attempt('suggestion'+str(sug_position), speed, slides)==0:
                                wordpos = len(sentence_words[w])
                                        
            
            #tap a word separator at the end of each word
            if wordpos == len(sentence_words[w]) and w<len(sentence_separators): #done typing word
                self.tote_attempt(sentence_separators[w], speed, slides)
                    #tap a space except for the last word
                        #[to do - match separators in original sentence]
                    
        
        print("--- Done typing ---")
        self.keyboard.outputbuffer+=self.keyboard.current_word
        print("".join(self.keyboard.outputbuffer))
        return {"sentence": sentence,
                "output": "".join(self.keyboard.outputbuffer), 
                "wpm": wpm(self.keyboard.taps),
                "kspc": kspc(self.keyboard.taps, sentence),
                "taps": self.keyboard.taps}

    def attemptDeletes(self,n_deletes,speed,slides):
        to_delete = n_deletes   
        print("attempting",to_delete,"deletes")
        while to_delete>0:
            t.sleep(0.5)
            #try to delete
            pos = self.finger.moveFingerKinematic('delete', self.keyboard, speed, slides)
            outcome=self.keyboard.outputLetter(pos)
            print("tried  to delete, result was", outcome)
            
            if outcome!=None:
                #subcase: we hit delete, good
                if outcome['type'] == 'delete':
                    print("good delete")
                    to_delete-=1
                else:
                    #subcase: we didn't hit delete
                    if outcome['type'] == 'char': #hit some other plain char key
                        #now we have another one in the composing buffer..
                        to_delete+=1
            else:
                continue
                        
        print('--done deleting--')
        
    
    def typeSentenceWithCorrection(self, sentence, speed, noticeprob, slides='on'):
        
        current_word_counter = 0
        # 1. split sentence into words
        sentence_words = re.split("[^\w]", sentence)
        current_word = sentence_words[current_word_counter]

        print(sentence_words)

        
        #reset to keyboard center at start
        self.finger.position=[round(self.keyboard.xdim/2),round(self.keyboard.ydim/2)]
        self.eye.position=[round(self.keyboard.xdim/2),round(self.keyboard.ydim/2)]
        
        #reset keyboard buffer
        self.keyboard.outputbuffer = []
        self.keyboard.current_word = []
        dist = 0
        taps = []
        intended = []

        # 2. for each word, type every letter
        
        for word in sentence_words:
            
            print ('processing word '+word)

            wordpos = 0
            while wordpos < len(word):
                
                # 2.1 search for key in keyboard
                #move the eye to the imagined location of the letter -  if not found, try randomly another quadrant of the keyboard
                print ("searching for ", word[wordpos], end="\r")
                found = False
                total_time=0
                searchcount=1
                while not found:
                    print ("\r searching for "+ word[wordpos]+ "  "+str(searchcount), end="\r")
                    found, time = self.eye.find_target(word[wordpos], self.keyboard, factor=1)
                    if not found:
                        searchcount+=1
                        self.eye.position[0]=random.randint(0,self.keyboard.xdim)
                        self.eye.position[1]=random.randint(0,self.keyboard.ydim)
                    total_time += time
                print('\n')
                
                # 2.2 when found, press it
                #move the finger to the key
                pos = self.finger.moveFingerKinematic(word[wordpos], self.keyboard, speed, slides)

                #see the outcome of the tap
                outcome=self.keyboard.outputLetter(pos)
                
                if outcome!=None and outcome['label']==word[wordpos]:
                    print("success")
                    wordpos+=1
                    
                else:
                    #first fix  the shit
                    if outcome!=None and outcome['label']!=word and (outcome['type']=='suggestion' or outcome['type']=='char'):
                        print("wrong key 1", outcome, "for intent", word[wordpos])
                        self.attemptDeletes(len(outcome['label']),speed,slides)
                    
                    #then try to reinput
                    
                    #keep trying if no hit if no target, or wrong target
                    while (outcome==None or outcome['label']!=word[wordpos]):
                        print("wrong key 2", outcome, "for intent", word[wordpos])
                        
                        #try again
                        pos = self.finger.moveFingerKinematic(word[wordpos], self.keyboard, speed, slides)
                        outcome=self.keyboard.outputLetter(pos)

                        
                        #case 1 - hit blank space
                        if outcome==None:
                            continue

                        #case 2 - hit special key
                        if outcome['type'] == 'modifier':
                            continue
                        
                        #case 3 - hit suggestion key
                        if outcome['type'] == "suggestion":
                            # we wanted to hit a key but we hit a suggestion key, now we need to delete all of it.
                            self.attemptDeletes(len(outcome['label']),speed,slides)
                            continue
                        
                        #case 4 - hit a letter
                        # Attempt to notice it and fix it
                        if outcome['type'] == 'char':
                            if outcome['label']==word[wordpos]:
                                print("success2")
                                break
                            else:
                                self.attemptDeletes(1,speed,slides)
                                continue
                        
                        #case 5  - hit delete instead of the desired key
                        if outcome['type'] == 'delete':
                            #special   case  -  if target was 1st letter of composing word
                            if len(self.keyboard.current_word)==0 and wordpos==0:
                                #try to enter the space
                                word=" "+word
                                wordpos=0
                                continue
                            else:
                                #accidentally deleted good letter, target is previous letter now
                                wordpos-=1
                                print('new input target', word[wordpos])
                                continue
                    wordpos+=1
                
                # 2.3 with increasing probability, check the suggestions to see if the desired word is there
                
                #before moving to the next letter, chance to observe if a suggestion is available
                #chance depends on letters typed already in composing word - for each letter add a 20% chance

                if wordpos>=2:
                    chance = random.randint(0,100)
                    threshold = len(self.keyboard.current_word)*20
                    if chance<threshold:
                        print("checking suggestions for '"+word+"'")
                        sug_position = self.eye.scan_suggestions(word, self.keyboard)
                        if sug_position>=0:
                            print("word in suggestions"+str(sug_position))
                            
                            #try to hit that suggestion
                            pos = self.finger.moveFingerKinematic('suggestion'+str(sug_position), self.keyboard, speed, slides)
                            outcome=self.keyboard.outputLetter(pos)

                            print ("suggestion attempt",outcome)
                            
                            #handle none or wrong suggestion/key
                            
                            #first, fix the bad input
                            if outcome!=None and outcome['type']!='modifier' and outcome['label']!=word:
                                self.attemptDeletes(len(outcome['label']),speed,slides)
                                
                            #now try again
                            while outcome==None or outcome['label']!=word:
                                print ("trying for ",'suggestion'+str(sug_position), 
                                       "at", self.keyboard.keylist['suggestion'+str(sug_position)]['center'], 
                                       "from", self.finger.position)
                                pos = self.finger.moveFingerKinematic('suggestion'+str(sug_position), self.keyboard, speed, slides)
                                outcome = self.keyboard.outputLetter(pos)
                                print ("suggestion attempt 2",outcome, "at", pos['tap'])
                                
                                if outcome==None:
                                    #just try again
                                    continue

                                if outcome['label']==word:
                                    break
                                    
                                if outcome['type']!=['modifier']: #ie char or other sug
                                    print("instead of sug, key or other sug")
                                    self.attemptDeletes(len(outcome['label']),speed,slides)
                                    continue
                            #suggestion entered, on to next word
                            break  
                        else:
                            print("not found")
                        
    
                #finally, check that if we just finished a word, if so move to the next
                #if len(self.keyboard.current_word) == 0 and re.search("[\w]",sentence[i+1]): #no composing word and next to type is char
                #    current_word_counter+=1
                #    print ("moving to next word:" + sentence_words[current_word_counter])

                # 2.4 type a word separator and move to next word
                if wordpos == len(word)-1: #done typing word
                    #tap a space except for the last word
                        #[to do - match separators in original sentence]
                    pos = self.finger.moveFingerKinematic(' ', self.keyboard, speed, slides)
                    outcome=self.keyboard.outputLetter(pos)
                    #could be none, fix it
                    while outcome!=' ':
                        self.attemptDeletes(len(outcome),  speed, slides)
        
                

        print("--- Done typing ---")
        self.keyboard.outputbuffer+=self.keyboard.current_word
        print("".join(self.keyboard.outputbuffer))
        return {"sentence": sentence,
                "output": "".join(self.keyboard.outputbuffer), 
                "wpm": wpm(self.keyboard.taps),
                "kspc": kspc(self.keyboard.taps, sentence),
                "taps": self.keyboard.taps}
