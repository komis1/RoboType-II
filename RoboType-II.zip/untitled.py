import datetime

from Decoder import *
from Finger import *
from LanguageModel import *
from TouchModel import *
from Keyboard import *
from metrics import *
from read_corpus import *
from visualiser import *
from Eye import *
import random
from Executor2 import *

mykeyboard = Keyboard('keyboards/qwerty-suggestions.xml', 'languagemodel.json', 'touchmodel.json', [1400,1000],[0,0], usedecoder=False)

f=open('virtual_participants/popts_all.json')
participants = sorted(list(json.load(f).keys()))
myfinger=Finger('virtual_participants/popts_all.json', "101")

#tps1=myfinger.typeSentenceWithCorrection(mykeyboard, "hello world", speed=1, noticeprob=1.1, slides='on')

#print(tps1['output'])
#print(mykeyboard.outputbuffer)

## eye test

eye = Eye()
eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]

#eye.position = [700, 100]
#print(list(mykeyboard.idx.intersection((eye.position[0], eye.position[1], eye.position[0], eye.position[1]), objects='raw')))
#print(eye.return_keys(mykeyboard, 1, nresults=3))
#target = 'a'
#total_time = 0
#found = False

#while not found:
#    found, time = eye.find_target(target, mykeyboard, factor=1)
#    if not found:
#        eye.position[0]=random.randint(0,mykeyboard.xdim)
#        eye.position[0]=random.randint(0,mykeyboard.ydim)
#    total_time += time

#print ("total seach time = ", total_time)


#Executor Adun

executor = Executor2(myfinger, eye, mykeyboard)

taps = executor.typeSentenceWithCorrection2("hello mama", speed=1, noticeprob=1, slides='on', completions=True)

pretty_dict = json.dumps(taps, indent=4)
print(pretty_dict)
