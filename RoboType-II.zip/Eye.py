### Class to simulate eye kinematics
import json
import numpy as np
import math
import random
from metrics import *

class Eye:
    #an eye moves to some coordinates. It fixates, absorbs the information there, then moves to other coordinates to scan
    
    def __init__(self):
        self.position=[0,0]
        self.ocular_speed = 1000 #pixels/millisecond
        self.read_time=[50,70]
        self.saccade_latency=[50,70]
        self.move_speed=[25,35]
        self.pos_list = []

    def move_eye(self, old_pos, new_pos):
        #https://www.sciencedirect.com/topics/engineering/saccade-amplitude
        #first a latency ~150ms
        #next a movement that takes 30–100 ms

        time = random.randint(self.saccade_latency[0],self.saccade_latency[1]) + random.randint(self.move_speed[0],self.move_speed[1])
        self.position = new_pos
        self.pos_list.append({'position':self.position, 'time':time})
        return time

    def return_keys(self, keyboard, factor, nresults=3):
        #xmin, ymin, xmax, ymax       

        objects = list(keyboard.idx.intersection(
                                                    (self.position[0]-factor*keyboard.keywidth, self.position[1]-factor*keyboard.keywidth,
                                                     self.position[0]+factor*keyboard.keywidth, self.position[1]+factor*keyboard.keywidth),
                                                 objects='raw'))
        return objects

    def find_target_at_current_position(self, target, keyboard, factor):

        objects_visible = self.return_keys(keyboard, factor)

        total_time = random.randint(self.read_time[0], self.read_time[1]) 
        #in ms,time to scan through all the objects at current eye coords and find the target
                        #https://en.wikipedia.org/wiki/Eye_movement_in_reading        
        
        for o in objects_visible:
            if o == target:
                return True, total_time
        
        return False, total_time

    def scan_suggestions(self, target, keyboard):
        #serially look at suggestions to see if we have what we need
        #also consider making this an event-based thing (when writing something at the top row)
        time = 0

        eye_positions=[]
        
        for i in range(keyboard.n_suggestion_keys):
            #place the eye on the suggestion
            time += self.move_eye(self.position, [keyboard.keylist['suggestion'+str(i)]['center'][0], 
                                                 keyboard.keylist['suggestion'+str(i)]['center'][1]])
            #read suggestion
            time +=random.randint(self.read_time[0], self.read_time[1])

            eye_positions.append({"pos":self.position,"time":time})
            
            #check the content
            if keyboard.keylist['suggestion'+str(i)]['label'] == target:
                return i, eye_positions
        
        return -1, eye_positions
            
