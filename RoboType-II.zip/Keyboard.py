### Class to simulate virtual keyboards
import xml.etree.ElementTree as ET
from rtree import index
import math
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import re
from Trie import *

class Keyboard:

    keylist = {}
    keywidth = 0
    usedecoder = False
    decoderdisabled = False
    decoderbuffer = []
    n_suggestion_keys = 0;
    taps = []
    
    
    xdim=0
    ydim=0
    maxdist=0
    xdim_phys=0
    ydim_phys=0
    outputbuffer = []
    current_word = []
  
    

    def __init__(self, kfile, lmfile, tmfile, dims_px, dims_mm, usedecoder=False, decoderngrams=4):
        self.xdim=dims_px[0]
        self.ydim=dims_px[1]
        self.xdim_phys=dims_mm[0]
        self.ydim_phys=dims_mm[1]

        self.readxml(kfile, self.xdim, self.ydim)

        self.usedecoder = usedecoder
        if self.usedecoder:
            self.decoder = Decoder(kfile, lmfile, tmfile, decoderngrams)
            self.decoderngrams = decoderngrams
            self.decoderdisabled = False

        dists = []
        keys = list(self.keylist.keys())
        for i in range (len(keys)-1):
            for j in range (i+1,len(keys)-1):
                dist = math.sqrt((self.keylist[keys[j]]['center'][0]-self.keylist[keys[i]]['center'][0])**2 + (self.keylist[keys[j]]['center'][1]-self.keylist[keys[i]]['center'][1])**2)
                dists.append(dist)
        self.maxdist=max(dists)
        print(self.maxdist)
        print(self.usedecoder)

        self.dictionary = Trie()
        #dictionary.insert_from_csv("support_files/unigram_freq.csv", limit=50000)
        self.dictionary = Trie.load_from_file(file="test.pickle")


    ## print keyboard letters and dimensions
    def printkeyboard(self):
        print("keyboard size "+str(self.xdim)+" x "+str(self.ydim))
        for i in self.keylist:
            print(i)
            print()
        print(self.keylist)

    ### matches xy finger coordinates, with key bounding boxes, and returns the key
    ### optionally uses a decoder to correct the pressed key
    def outputLetter(self, fingerpos):

        result = None
        
        targets = list(
                self.idx.intersection(
                    (fingerpos['touchup']['x'], fingerpos['touchup']['y'], 
                     fingerpos['touchup']['x'], fingerpos['touchup']['y']),
                    objects='raw')
                )
        
        if len(targets)==1: #we hit a key
            
            targetlabel = self.keylist[targets[0]]['label']
            
            if self.usedecoder and self.keylist[targets[0]]['type']=='char': #predict likely key except special ones
                #if len(self.decoderbuffer)==self.decoderngrams:
                if len(self.decoderbuffer)>0: #don't decode if first letter
                    targets[0] = self.decoder.decode(self.decoderbuffer, targets[0])

                #add to buffer
                if len(self.decoderbuffer)>=self.decoderngrams-1: #Remove earliest if full
                    self.decoderbuffer.pop(0)
                if len(targets[0])==1: #don't put in deletes, nones etc
                    self.decoderbuffer.append(v[0])

                #if letters[0]==' ': #clear the buffer on space
                #    self.decoderbuffer=[]
                
            if self.keylist[targets[0]]['type']=='char': #not a special key - single char key label
                
                #if is a space or word terminator
                if re.search(" ",targets[0]):
             #       print("\tKB:inputted", targetlabel)
                #if re.search("[^\w]",targets[0]): 
                    #commit to the buffer
                    #print("bc")
                    self.outputbuffer+=self.current_word+[targetlabel]
                    #reset current word
                    self.current_word=[]
             #       print ("\tKB:output", self.outputbuffer)
                    
                else: #plain key
             #       print("\tKB:inputted", targetlabel)
                    self.current_word.append(targetlabel)
                    self.updateSuggestions()
                    
                #return the pressed char
                result = self.keylist[targets[0]]
            
            else: #is a special key
            #    print("\tKB:inputted", targetlabel)
                
                if self.keylist[targets[0]]['type']=='suggestion': #we hit a suggestion key
                                        
                    if self.keylist[targets[0]]['label']=='---':
                        #no effect
                        result = None
                    else:
                        self.current_word = list(targetlabel)
                        #self.outputbuffer+=self.current_word
                        #self.outputbuffer.append(' ')
                        #self.current_word=[]
                        #return the suggestion key
                        result = self.keylist[targets[0]].copy()
                        self.updateSuggestions()
                
                if self.keylist[targets[0]]['type']=='delete': #we hit a delete key
                    if len(self.current_word)>0:
                        self.current_word.pop()
                        self.updateSuggestions()
                    else: # we are either at  the very first char or must move to prev word
                        if len(self.outputbuffer)!=0:
                            self.outputbuffer.pop() #remove word terminator
                            #find last word and make it the composing one
                            fmatch=None
                            #for m in re.finditer("[^\w]", "".join(self.outputbuffer)):
                            for m in re.finditer(" ", "".join(self.outputbuffer)):
                            	fmatch=m

                            if fmatch!=None: #it was not the first word
                                self.current_word=self.outputbuffer[fmatch.span()[1]:]
                                self.outputbuffer=self.outputbuffer[:fmatch.span()[0]]
                            else:
                                self.current_word  = self.outputbuffer
                                self.outputbuffer = []
                            self.updateSuggestions()
                    
                    #return the delete key
                    result = self.keylist[targets[0]]                   
                    
        else:
            result = None
            
        tap={}
        if result!=None:
            tap['label']= result
        else:
            tap['label']= 'none'
        tap['fingerparams']= fingerpos
        self.taps.append(tap)

        # print("\tKB:current word", self.current_word)

        return result


    def updateSuggestions(self):
        suglist = []
        #make a guess using the trie, if >2 letters have been entered
        if len(self.current_word)>=2:
            suggestions = self.dictionary.query_with_limit("".join(self.current_word), 
                                                           wordlenlimit=-1, suglimit=self.n_suggestion_keys)
            suglist = list(suggestions.keys())

        #pad out the suggestion list if fewer than the provided ones (also if no suggestions should be provided)
        for i in range(0,self.n_suggestion_keys-len(suglist)):
            suglist.append("---")
            
        #now modify the suggestion key labels
        for i in range(0,self.n_suggestion_keys):
            self.keylist['suggestion'+str(i)]['label']=suglist[i]
      #      print("\tKB:", "'"+self.keylist['suggestion'+str(i)]['label']+"'")
        

    ## create a keyboard from an XML file
    def readxml(self,file, xdim, ydim):
        self.keylist={}
        mytree = ET.parse(file)
        myroot = mytree.getroot()

        kw = round(float(myroot.attrib['keyWidth'].split("%")[0])*xdim/100)
        kh = round(float(myroot.attrib['keyHeight'].split("%")[0]))*ydim/100

        hkeygap = round(float(myroot.attrib['horizontalGap'].split("%")[0])*xdim/100)
        vkeygap = round(float(myroot.attrib['verticalGap'].split("%")[0])*ydim/100)

        actualkh = kh-vkeygap

        self.keywidth=kw

        print("standard key dims", kw, kh)

        rowcount = -1
        keycount = -1
        for x in myroot.findall('Row'):
            rowcount+=1
            extragap = 0
            prevcenter = [0,0]
            prevlen=0

            for child in x:

                keycount+=1
                klabel = ''
                center=[0,0]
                actualw = 0

                if 'keyWidth' in child.attrib: #special key
                    actualw=round(float(child.attrib['keyWidth'].split("%")[0])*xdim/100)
                else:
                    actualw=kw

                actualw = actualw-hkeygap

                if 'horizontalGap' in child.attrib:
                    extragap=round(float(child.attrib['horizontalGap'].split("%")[0])*xdim/100)

                if keycount==0:
                    center[0] = extragap+hkeygap/2+actualw/2
                else:
                    center[0] = prevcenter[0]+prevlen/2+actualw/2+hkeygap

                center[1]= kh/2+rowcount*kh


                if 'keyType' in child.attrib:
                    if child.attrib['keyType']=='suggestion':
                        self.n_suggestion_keys+=1
                    ktype = child.attrib['keyType']
                else:
                    ktype = 'char'
                    
                if 'keyLabel' in child.attrib:
                    klabel=child.attrib['keyLabel']
                else:
                    klabel=child.attrib['keyIcon'].split("_")[2]

                kletter = klabel

                if 'codes' in child.attrib:
                    kcode =child.attrib['codes']

                if all(c in ('_') for c in klabel): #is an additional spacebar
                    kletter = ' '

                key ={
                    'keycode': kletter,
                    'label': kletter,
                    'center':center,
                    'xlen':actualw,
                    'ylen':actualkh,
                    'type':ktype,
                    #left bottom right top
                    'bbox':{
                            'left':center[0]-actualw/2,
                            'bottom':center[1]-actualkh/2,
                            'right':center[0]+actualw/2,
                            'top':center[1]+actualkh/2
                            }
                    }
                #print(klabel, center, key['bbox'], actualw, kh)
                self.keylist[klabel]=key
                prevcenter = center
                prevlen = actualw

            keycount=-1

        #rtree index
        self.idx = index.Index()
        self.spaceidx = index.Index()

        counter=0
        for i in self.keylist:
            #insert in master rtree
            self.idx.insert(counter, (self.keylist[i]['bbox']['left'],
                                              self.keylist[i]['bbox']['bottom'],
                                              self.keylist[i]['bbox']['right'],
                                              self.keylist[i]['bbox']['top']), self.keylist[i]['label'])

            if all(c in ('_') for c in i) or i==' ': #is a space key
                self.spaceidx.insert(counter, (self.keylist[i]['bbox']['left'],
                                              self.keylist[i]['bbox']['bottom'],
                                              self.keylist[i]['bbox']['right'],
                                              self.keylist[i]['bbox']['top']), i)
            counter+=1

    ## visualise the keyboard
    def plot(self,figw):
        figh=round(self.ydim/self.xdim*figw,1)
        
        fig, ax = plt.subplots(figsize=(figw, figh))

        rect = Rectangle((0,-self.ydim), self.xdim,self.ydim,
                             linewidth=1,edgecolor='black',facecolor='darkgrey')
        ax.add_patch(rect)

        #plot the keyboard
        for i in self.keylist:
            ax.plot(self.keylist[i]['center'][0], -self.keylist[i]['center'][1], marker='.', color='whitesmoke')
            ax.text(self.keylist[i]['center'][0], -self.keylist[i]['center'][1], self.keylist[i]['label'],
                    horizontalalignment='center',
                    verticalalignment='center',fontsize=16, color='grey')
            rect = Rectangle((self.keylist[i]['bbox']['left'],-self.keylist[i]['bbox']['bottom']),
                             self.keylist[i]['xlen'],-self.keylist[i]['ylen'],
                             linewidth=1,edgecolor='grey',facecolor='whitesmoke')
            ax.add_patch(rect)

        plt.show()
