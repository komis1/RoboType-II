### Utility functions to calculate text entry metrics from produced input stream dictionaries

def wpm(taps, buffer):
    #exclude shift, bsp etc
    typed_entries = len(buffer)
    time = 0
    #for i in range(len(taps)):
    #    time+=taps[i]['fingerparams']['time']
    time = taps[len(taps)-1]['fingerparams']['time']
    minutes=(time/1000/60)
    return (typed_entries/5)/minutes

def kspc(taps, buffer):
    #exclude shift, bsp etc
    typed_entries=0
    for tap in taps:
        if tap['label']!='none' and (tap['label']['type']=='char' or tap['label']['type']=='suggestion'):
            typed_entries+=1
    return typed_entries/len(buffer)
